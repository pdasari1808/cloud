URL : http://ec2-44-201-143-45.compute-1.amazonaws.com:5000
DB used: dynamodb
Login Page Credentials: user:pdasari@uab.edu , pass:pdasari@123

NOTE:
- extract and push webapp.zip and lambda.zip to git repository
- ec2_instance.pem is used to ssh into the server
- .env file will be used in the server